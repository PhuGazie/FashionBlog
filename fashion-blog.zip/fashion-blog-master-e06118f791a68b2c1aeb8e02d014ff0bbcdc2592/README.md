# Fashion Blog

- In this exercise you will be coding a front end for a fashion blog in HTML and CSS.
- First start off by downloading the starter files here.
- Your job is to use the attached mockup as a guide to develop the template as pixel-perfect as possible.